﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test_Basic.Models;

namespace Test_Basic.Controllers
{

    public class EmployeeController : Controller
    {
        //[Authorize]
        public ActionResult Index(string searchName)
        {
            try
            {
                if (Session["username"]==null)
                {
                    return RedirectToAction("Login", "Home");
                }
            }
            catch
            {
                return RedirectToAction("Login", "Home");
            }
            //List<Employee> list = FetchFromDatabase();
            List<Employee> filteredUsers = new List<Employee>();
            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM dbo.tblEmployee WHERE Name LIKE @SearchName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SearchName", "%" + searchName + "%");

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int Id = reader.GetInt32(0);
                            string Name = reader.GetString(1);
                            string Address = reader.GetString(2);
                            DateTime DateofBirth = reader.GetDateTime(3);
                            string EmailId = reader.GetString(4);
                            string MobileNumber = reader.GetString(5);
                            int DepartmentId = reader.GetInt32(6);
                            Employee emp = new Employee()
                            {
                                 Id = Id, Name = Name, Address = Address, DateOfBirth = DateofBirth, EmailId = EmailId, MobileNumber = MobileNumber, DepartmentId = DepartmentId
                                };
                            filteredUsers.Add(emp);

                        }

                            
                        
                    }
                }
            }

            // Pass the filtered users to the view
            return View(filteredUsers);
        //}
        //    return View(list);
        }
        //[Authorize]
        public ActionResult Create()
        {
            return View();
        }

        //[Authorize]
        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            if (CheckEmployeeExists(employee.Name) == true)
            {
                ViewBag.Message = "Employee exists already!";
                return View();
            }
            AddDataToDatabase(employee);

            ViewBag.Message = employee.Name + " added successfully";
            return RedirectToAction("Index", "Employee");
        }

        private void AddDataToDatabase(Employee employee)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "INSERT INTO [dbo].[tblEmployee]\r\n           ([Name]\r\n           ,[Address]\r\n           ,[DateOfBirth]\r\n           ,[EmailId]\r\n           ,[MobileNumber]\r\n           ,[DepartmentId])\r\n     VALUES\r\n           (@Name,\r\n           @Address,\r\n           CAST(@DateOfBirth AS DateTime),\r\n           @EmailId,\r\n           @MobileNumber,\r\n           @DepartmentId)";


                using (SqlCommand command = new SqlCommand(query, connection))
                {



                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Address", employee.Address);
                    command.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                    command.Parameters.AddWithValue("@EmailId", employee.EmailId);
                    command.Parameters.AddWithValue("@MobileNumber", employee.MobileNumber);
                    command.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);


                    command.ExecuteNonQuery();
                }
            }
        }

        public ActionResult Edit(int id)
        {
            Employee emp = FetchFromDatabase(id);
           
            return View(emp);
        }

        //[Authorize]
        [HttpPost]
        public ActionResult Edit(Employee employee)
        {
            //Employee employee = FetchFromDatabase(id);
            EditDataInDatabase(employee);
            return RedirectToAction("Index", "Employee");

        }

        private void EditDataInDatabase(Employee employee)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "UPDATE [dbo].[tblEmployee]\r\n   SET [Name] = @Name\r\n      ,[Address] = @Address\r\n      ,[DateOfBirth] = @DateOfBirth\r\n      ,[EmailId] = @EmailId\r\n      ,[MobileNumber] = @MobileNumber\r\n      ,[DepartmentId] = @DepartmentId\r\n WHERE Id=@Id";


                using (SqlCommand command = new SqlCommand(query, connection))
                {



                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Address", employee.Address);
                    command.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                    command.Parameters.AddWithValue("@EmailId", employee.EmailId);
                    command.Parameters.AddWithValue("@MobileNumber", employee.MobileNumber);
                    command.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);
                    command.Parameters.AddWithValue("@Id", employee.Id);

                    command.ExecuteNonQuery();
                }
            }
        }

        //[Authorize]
        public ActionResult Delete(int id)
        {
            DeleteFromDatabase(id);


            return RedirectToAction("Index", "Employee");

        }

        private void DeleteFromDatabase(int id)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "DELETE FROM dbo.tblEmployee WHERE Id = @Id;";


                using (SqlCommand command = new SqlCommand(query, connection))
                {



                    command.Parameters.AddWithValue("@Id", id);
                    


                    command.ExecuteNonQuery();
                }
            }
        }
        private List<Employee> FetchFromDatabase()
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            string query = "SELECT * FROM dbo.tblEmployee";
            List<Employee> employees = new List<Employee>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Execute the query and obtain a data reader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        
                        // Check if the reader has any rows
                        if (reader.HasRows)
                        {
                            

                            while (reader.Read())
                            {
                                int Id = reader.GetInt32(0); 
                                string Name = reader.GetString(1); 
                                string Address = reader.GetString(2); 
                                DateTime DateofBirth = reader.GetDateTime(3);
                                string EmailId = reader.GetString(4);
                                string MobileNumber = reader.GetString(5);
                                int DepartmentId = reader.GetInt32(6);
                                employees.Add(new Employee { Id = Id, Name = Name, Address = Address,DateOfBirth = DateofBirth, EmailId = EmailId, MobileNumber = MobileNumber, DepartmentId = DepartmentId });

                            }
                            
                        }
                        
                    }
                }
            }
            return employees;
        }
        private bool CheckEmployeeExists(string Name)
        {
            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "SELECT COUNT(*) FROM dbo.tblEmployee WHERE Name = @Name";


                using (SqlCommand command = new SqlCommand(query, connection))
                {


                    command.Parameters.AddWithValue("@Name",Name);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;




                }
            }

        }
        private Employee FetchFromDatabase(int id)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            string query = "SELECT * FROM dbo.tblEmployee WHERE Id = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    // Execute the query and obtain a data reader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        
                        // Check if the reader has any rows
                        if (reader.HasRows)
                        {


                            while (reader.Read())
                            {
                                int Id = reader.GetInt32(0);
                                string Name = reader.GetString(1);
                                string Address = reader.GetString(2);
                                DateTime DateOfBirth = reader.GetDateTime(3);
                                string EmailId = reader.GetString(4);
                                string MobileNumber = reader.GetString(5);
                                int DepartmentId = reader.GetInt32(6);
                                return new Employee { Id = Id, Name = Name, Address = Address, DateOfBirth = DateOfBirth, EmailId = EmailId, MobileNumber = MobileNumber, DepartmentId = DepartmentId };

                            }

                        }

                    }
                }
            }
            return null;
        }
    }
}