﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test_Basic.Models;
using System.Data.SqlClient;
using System.Web.Security;
using System.Diagnostics;
using System.Reflection;
using System.Data;

namespace Test_Basic.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Register()
        {

            return View();
        }

        public ActionResult Login()
        {
            return View();
        }


 
        [HttpPost]
        public ActionResult Register(Users user)
        {
            if (CheckUsernameExists(user.username) == true)
            {
                ViewBag.Message = "User exists already!";
                return View();
            }
            
            AddDataToDatabase(user);
            //int Registration_id = FetchFromDatabase(user.username);
            //AddDataToRoleDatabase(Registration_id);
            ViewBag.Message = user.username + " registered successfully";
            return View();
        }

        private void AddDataToDatabase(Users user)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "INSERT INTO dbo.UserRegistration (username, MobileNumber, Gender, Address, DateOfBirth, EmailId, RegistrationDate) VALUES (@username, @MobileNumber, @Gender, @Address, @DateOfBirth, @EmailId, @RegistrationDate)";


                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    user.RegistrationDate = DateTime.Today;
                    string Role = "user";
                    command.Parameters.AddWithValue("@username", user.username);
                    command.Parameters.AddWithValue("@MobileNumber", user.MobileNumber);
                    command.Parameters.AddWithValue("@Gender", user.Gender);
                    command.Parameters.AddWithValue("@Address", user.Address);
                    command.Parameters.AddWithValue("@DateOfBirth", user.DateOfBirth);
                    command.Parameters.AddWithValue("@EmailId", user.EmailId);
                    command.Parameters.AddWithValue("@RegistrationDate", user.RegistrationDate);
                    command.Parameters.AddWithValue("@Role", Role);


                    command.ExecuteNonQuery();
                }
            }
        }

        //private void AddDataToRoleDatabase(int UserId)
        //{
        //    string Role = "user";
        //    string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();


        //        string query = "INSERT INTO dbo.Role (UserId, Role) VALUES (@UserId, @Role)";


        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {

                    

        //            command.Parameters.AddWithValue("@UserId", UserId);
        //            command.Parameters.AddWithValue("@Role", Role);



        //            command.ExecuteNonQuery();
        //        }
        //    }
        //}


        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            string username = model.username;
            string EmailId = model.EmailId;

            if (ValidateCredentials(username, EmailId) == true)
            {
                Session["username"] = username;
                if (GetRole(username) == "admin")
                {
                    Session["admin"] = "admin";
                }

                //FormsAuthentication.SetAuthCookie(username, false);

                return RedirectToAction("Index", "Employee");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid username or password.";
                
            }
            return View(model);




        }

        private bool ValidateCredentials(string username, string EmailId)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM dbo.UserRegistration WHERE username = @username AND EmailId = @EmailId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@EmailId", EmailId); 

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }
        private Users Bringuser(string username, string EmailId)
        {
            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "select username, EmailId from dbo.UserRegistration where username = @username AND EmailId = @EmailId";


                using (SqlCommand command = new SqlCommand(query, connection))
                {


                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@EmailId", EmailId);



                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string actual_username = reader.GetString(0);
                            string actual_EmailId = reader.GetString(1);

                            return new Users
                            {
                                username = actual_username,
                                EmailId = actual_EmailId

                            };
                        }
                    }
                }
            }
            return null;
        }

        private bool Verifycred(string EmailId, string EmailId_supplied)
        {

            return EmailId == EmailId_supplied;
        }
        private bool CheckUsernameExists(string username)
        {
            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "SELECT COUNT(*) FROM dbo.UserRegistration WHERE username = @username";


                using (SqlCommand command = new SqlCommand(query, connection))
                {


                    command.Parameters.AddWithValue("@username", username);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;




                }
            }
           
        }
        private int FetchFromDatabase(string username)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            string query = "SELECT * FROM dbo.UserRegistration WHERE username = @username";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
                    // Execute the query and obtain a data reader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {

                        // Check if the reader has any rows
                        if (reader.HasRows)
                        {


                            while (reader.Read())
                            {
                                int Id = reader.GetInt32(0);

                                return Id;

                            }

                        }

                    }
                }
            }
            return 0;
        }

        private string GetRole(string username)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = TestDB; integrated security = SSPI";
            string query = "SELECT Role FROM dbo.UserRegistration WHERE username = @username";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    // Execute the query and obtain a data reader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {

                        // Check if the reader has any rows
                        if (reader.HasRows)
                        {


                            while (reader.Read())
                            {
                                string Role = reader.GetString(0);

                                return Role;

                            }

                        }

                    }
                }
            }
            return "user";
        }


        public ActionResult Logout()
        {
            Session.Clear();
            return View("Login");
        }






    }
}